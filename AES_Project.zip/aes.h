#ifndef AES_H
#define AES_H

#include <vector>
#include <string>

using namespace std;

typedef unsigned char Byte;
typedef vector<Byte> ByteArray;

void SubBytes(ByteArray& state);
void ShiftRows(ByteArray& state);
void MixColumns(ByteArray& state);
void AddRoundKey(ByteArray& state, const ByteArray& roundKey);
void KeyExpansion(const ByteArray& key, vector<ByteArray>& roundKeys);

void InvSubBytes(ByteArray& state);
void InvShiftRows(ByteArray& state);
void InvMixColumns(ByteArray& state);

ByteArray AES_Encrypt(const ByteArray& input, const ByteArray& key);
ByteArray AES_Decrypt(const ByteArray& input, const ByteArray& key);

#endif // AES_H
