#include "aes.h"
#include <fstream>
#include <iostream>

using namespace std;

ByteArray ReadFromFile(const string& filename) {
    ifstream file(filename, ios::binary);
    ByteArray data;
    char ch;
    while (file.get(ch)) {
        data.push_back(static_cast<Byte>(ch));
    }
    file.close();
    return data;
}

void WriteToFile(const string& filename, const ByteArray& data) {
    ofstream file(filename, ios::binary);
    for (auto byte : data) {
        file.put(static_cast<char>(byte));
    }
    file.close();
}

int main() {
    string keyStr = "0123456789abcdef"; // 16 bytes = 128 bits key
    ByteArray key(keyStr.begin(), keyStr.end());

    // Mã hóa
    ByteArray plaintext = ReadFromFile("encrypt.txt");
    ByteArray ciphertext = AES_Encrypt(plaintext, key);
    WriteToFile("output_encrypt.txt", ciphertext);

    // Giải mã
    ByteArray cipherInput = ReadFromFile("decrypt.txt");
    ByteArray decryptedtext = AES_Decrypt(cipherInput, key);
    WriteToFile("output_decrypt.txt", decryptedtext);

    return 0;
}
