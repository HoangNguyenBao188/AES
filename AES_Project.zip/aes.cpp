#include "aes.h"
#include <iostream>

using namespace std;

void SubBytes(ByteArray& state) {
    // Dummy SubBytes
}

void ShiftRows(ByteArray& state) {
    // Dummy ShiftRows
}

void MixColumns(ByteArray& state) {
    // Dummy MixColumns
}

void AddRoundKey(ByteArray& state, const ByteArray& roundKey) {
    for (int i = 0; i < state.size(); i++) {
        state[i] ^= roundKey[i];
    }
}

void KeyExpansion(const ByteArray& key, vector<ByteArray>& roundKeys) {
    // Dummy KeyExpansion
    roundKeys.push_back(key);
    for (int i = 1; i <= 10; ++i) {
        roundKeys.push_back(key); // Placeholder
    }
}

void InvSubBytes(ByteArray& state) {
    // Dummy InvSubBytes
}

void InvShiftRows(ByteArray& state) {
    // Dummy InvShiftRows
}

void InvMixColumns(ByteArray& state) {
    // Dummy InvMixColumns
}

ByteArray AES_Encrypt(const ByteArray& input, const ByteArray& key) {
    ByteArray state = input;
    vector<ByteArray> roundKeys;
    KeyExpansion(key, roundKeys);

    AddRoundKey(state, roundKeys[0]);
    for (int round = 1; round < 10; round++) {
        SubBytes(state);
        ShiftRows(state);
        MixColumns(state);
        AddRoundKey(state, roundKeys[round]);
    }
    SubBytes(state);
    ShiftRows(state);
    AddRoundKey(state, roundKeys[10]);
    return state;
}

ByteArray AES_Decrypt(const ByteArray& input, const ByteArray& key) {
    ByteArray state = input;
    vector<ByteArray> roundKeys;
    KeyExpansion(key, roundKeys);

    AddRoundKey(state, roundKeys[10]);
    for (int round = 9; round > 0; round--) {
        InvShiftRows(state);
        InvSubBytes(state);
        AddRoundKey(state, roundKeys[round]);
        InvMixColumns(state);
    }
    InvShiftRows(state);
    InvSubBytes(state);
    AddRoundKey(state, roundKeys[0]);
    return state;
}
